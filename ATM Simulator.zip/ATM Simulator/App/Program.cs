﻿using System;
using System.Collections.Generic;
using System.IO;

namespace ATMSimulator
{
    class Account
    {
        public string AccountNumber { get; set; }
        public string Name { get; set; }
        public string Pin { get; set; }
        public decimal Balance { get; set; }

        public Account(string accountNumber, string name, string pin, decimal balance)
        {
            AccountNumber = accountNumber;
            Name = name;
            Pin = pin;
            Balance = balance;
        }

        public override string ToString()
        {
            return $"{AccountNumber},{Name},{Pin},{Balance}";
        }
    }

    class Program
    {
        static string path = @""; //Enter your local accounts.txt path file inside the quotation marks
        static List<Account> accounts = new List<Account>();

        static void Main()
        {
            LoadAccounts();

            Console.WriteLine("=== Welcome to ATM Simulator ===");
            Console.Write("Enter Account Number: ");
            string accNum = Console.ReadLine();
            Console.Write("Enter PIN: ");
            string pin = Console.ReadLine();

            Account user = Authenticate(accNum, pin);

            if (user != null)
            {
                ShowMenu(user);
                SaveAccounts();
            }
            else
            {
                Console.WriteLine("Invalid login. Exiting...");
            }
        }

        static void LoadAccounts()
        {
            if (File.Exists(path))
            {
                string[] lines = File.ReadAllLines(path);
                foreach (string line in lines)
                {
                    var parts = line.Split(',');
                    if (parts.Length == 4)
                    {
                        accounts.Add(new Account(
                            parts[0],
                            parts[1],
                            parts[2],
                            decimal.Parse(parts[3])
                        ));
                    }
                }
            }
        }

        static void SaveAccounts()
        {
            List<string> lines = new List<string>();
            foreach (var acc in accounts)
            {
                lines.Add(acc.ToString());
            }
            File.WriteAllLines(path, lines);
        }

        static Account Authenticate(string accountNumber, string pin)
        {
            foreach (var acc in accounts)
            {
                if (acc.AccountNumber == accountNumber && acc.Pin == pin)
                {
                    return acc;
                }
            }
            return null;
        }

        static void ShowMenu(Account user)
        {
            int choice;
            do
            {;
                Console.WriteLine($"Hello, {user.Name}!");
                Console.WriteLine();
                Console.WriteLine("1. Check Balance");
                Console.WriteLine("2. Deposit");
                Console.WriteLine("3. Withdraw");
                Console.WriteLine("4. Exit");
                Console.Write("Enter choice: ");

                if (!int.TryParse(Console.ReadLine(), out choice)) choice = 0;

                switch (choice)
                {
                    case 1:
                        Console.WriteLine($"Balance: {user.Balance}");
                        break;
                    case 2:
                        Console.Write("Enter deposit amount: ");
                        if (decimal.TryParse(Console.ReadLine(), out decimal dep))
                        {
                            user.Balance += dep;
                            Console.WriteLine("Deposit successful.");
                        }
                        break;
                    case 3:
                        Console.Write("Enter withdrawal amount: ");
                        if (decimal.TryParse(Console.ReadLine(), out decimal wd))
                        {
                            if (wd <= user.Balance)
                            {
                                user.Balance -= wd;
                                Console.WriteLine("Withdrawal successful.");
                            }
                            else
                            {
                                Console.WriteLine("Insufficient balance!");
                            }
                        }
                        break;
                    case 4:
                        Console.WriteLine("Exiting session...");
                        break;
                    default:
                        Console.WriteLine("Invalid option. Try again.");
                        break;
                }

            } while (choice != 4);
        }
    }
}
