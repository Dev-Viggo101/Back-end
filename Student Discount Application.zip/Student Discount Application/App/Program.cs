﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App
{
    enum Menu
    {
        CaptureDetails = 1,
        CheckDiscountQualification,
        ShowQualificationStats,
        Exit
    }
    internal class Program
    {
        public class Student
        {
            public string fullName;
            public char resStudent;
            public int yearOnCampus;
            public int yearOnRes;
            public double monthlyAllowance;
            public double averageMark;
        }

        static List<Student> students = new List<Student>();
        static List<Student> qualStudent = new List<Student>();

        static void addStudent()
        {
            char moreApplicants;
            do
            {
                Console.Clear();

                Console.Write("Enter fullname: ");
                string fullname = Console.ReadLine();

                Console.Write("Resident student (Y/N): ");
                if (!char.TryParse(Console.ReadLine().ToLower(), out char resStudent)) return;

                Console.Write("Student year: ");
                if (!int.TryParse(Console.ReadLine(), out int yearOnCampus)) return;

                Console.Write("Current resident year: ");
                if (!int.TryParse(Console.ReadLine(), out int yearOnRes)) return;

                Console.Write("Monthly allowance/salary: ");
                if (!double.TryParse(Console.ReadLine(), out double monthlyAllowance)) return;

                Console.Write("Average mark across all subjects: ");
                if (!double.TryParse(Console.ReadLine(), out double averageMark)) return;

                students.Add(new Student
                {
                    fullName = fullname,
                    resStudent = resStudent,
                    yearOnCampus = yearOnCampus,
                    yearOnRes = yearOnRes,
                    monthlyAllowance = monthlyAllowance,
                    averageMark = averageMark
                });

                Console.Write("Capture more applicants (Y/N): ");
                if (!char.TryParse(Console.ReadLine().ToLower(), out moreApplicants)) return;
            }
            while (moreApplicants != 'n');
        }

        static void discountQual()
        {
            Console.Clear();

            if(students.Count == 0)
            {
                Console.WriteLine("No students have been added yet.");
                Console.WriteLine("Press any key to continue.");
                Console.ReadKey();
                return;
            }

            int i = 1;

            foreach (var stud in students)
            {
                Console.WriteLine($"{i}. {stud.fullName}");
                i++;
            }

            int qualCheck;

            while (true)
            {
                Console.Write("Which student's discount qualification would you like to check: ");
                if (int.TryParse(Console.ReadLine(), out qualCheck) && qualCheck >= 1 && qualCheck <= students.Count)
                {
                    break;
                }
                Console.WriteLine("Invalid selection. Please try again.");
            }

            var student = students[qualCheck - 1];

            if (student.resStudent == 'y' && student.yearOnRes > 0 && student.averageMark >= 85 && student.monthlyAllowance < 1000)
            {
                qualStudent.Add(student);
                Console.WriteLine($"{student.fullName} successfully qualified for the discount!");
            }
            else
            {
                Console.WriteLine($"Unfortunately {student.fullName} does not qualify for the discount");
            }

            Console.WriteLine("Press any key to continue.");
            Console.ReadKey();
        }

        static void qualStats()
        {
            Console.Clear();
            
            if(qualStudent.Count == 0)
            {
                Console.WriteLine("No students have qualified yet.");
            }
            else
            {
                Console.WriteLine("Qualified Students:");
                foreach (var stud in qualStudent)
                {
                    Console.WriteLine($"{stud.fullName} - Average Mark: {stud.averageMark}, Allowance: {stud.monthlyAllowance}");
                }
            }
            Console.WriteLine("\nPress any key to continue.");
            Console.ReadKey();
        }

        static void Main(string[] args)
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("1. Enter Student Details");
                Console.WriteLine("2. Discount Qualification");
                Console.WriteLine("3. Qualification Stats");
                Console.WriteLine("4. Exit");
                Console.Write("Select an option (1-4): ");

                if(int.TryParse(Console.ReadLine(), out int option) && Enum.IsDefined(typeof(Menu), option))
                {
                    switch((Menu)option)
                    {
                        case Menu.CaptureDetails:
                            addStudent();
                            break;

                        case Menu.CheckDiscountQualification:
                            discountQual();
                            break;

                        case Menu.ShowQualificationStats:
                            qualStats();
                            break;

                        case Menu.Exit:
                            Environment.Exit(0);
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Invalid option. Press any key to continue...");
                    Console.ReadKey();
                }
            }
            Console.ReadKey();
        }
    }
}
