﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App
{
    internal class membersManager
    {
        private List<Student> student = new List<Student>();
        private List<Lecturer> lecturer = new List<Lecturer>();

        public void registerStudent()
        {
            Console.Clear();

            Student s = new Student();
            Console.Write("Enter full name: ");
            s.fullname = Console.ReadLine();

            Console.Write("Enter student ID: ");
            if(!int.TryParse(Console.ReadLine(), out int Id))
            {
                Console.WriteLine("Invalid ID. Must be a number.");
                return;
            }

            if (studentExists(Id))
            {
                Console.WriteLine("Student ID already exists!");
                return;
            }

            s.Id = Id;

            student.Add(s);
            Console.WriteLine("Student registered successfully!");
            Console.ReadKey();
        }

        public void registerLecturer()
        {
            Console.Clear();

            Lecturer l = new Lecturer();
            Console.Write("Enter full name: ");
            l.fullname = Console.ReadLine();

            Console.Write("Enter lecturer ID: ");
            if(!int.TryParse(Console.ReadLine(), out int Id))
            {
                Console.WriteLine("Invalid ID. Must be a number");
                return;
            }

            if (lecturerExists(Id))
            {
                Console.WriteLine("Lecturer ID already exists!");
                return;
            }

            l.Id = Id;

            Console.Write("Enter department: ");
            l.department = Console.ReadLine().ToUpper();

            lecturer.Add(l);
            Console.WriteLine("Lecturer registered successfully!");
            Console.ReadKey();
        }

        public void viewStudents()
        {
            Console.Clear();
            if (student.Count == 0)
            {
                Console.WriteLine("No students registered yet.");
            }
            else
            {
                Console.WriteLine("Registered Students:");
                foreach (var s in student)
                {
                    s.displayInfo();
                }
            }
            Console.ReadKey();
        }

        public void viewLecturers()
        {
            Console.Clear();
            if(lecturer.Count == 0)
            {
                Console.WriteLine("No lecturers registered yet.");
            }
            else
            {
                Console.WriteLine("Registered Lecturers:");
                foreach (var l in lecturer)
                {
                    l.displayInfo();
                }
            }
            Console.ReadKey();
        }

        public bool studentExists(int Id)
        {
            foreach (var s in student)
            {
                if(s.Id == Id)
                {
                    return true;
                }
            }
            return false;
        }

        public bool lecturerExists(int Id)
        {
            foreach (var l in lecturer)
            {
                if (l.Id == Id)
                {
                    return true;
                }
            }
            return false ;
        }
    }
}
