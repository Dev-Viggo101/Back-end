﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App
{
    enum Menu
    {
        Register = 1,
        ViewRegisteredMembers,
        PlaceAnOrder,
        ViewPlacedOrders,
        Exit
    }

    enum RegisteredMembers 
    {
        Student = 1,
        Lecturer
    }

    enum ViewMembers
    {
        Student = 1,
        Lecturer
    }
    internal class Program
    {
        static membersManager membersManager = new membersManager();
        static ordersManager ordersManager = new ordersManager();
        static void register()
        {
            Console.Clear();
            while (true)
            {
                Console.Clear();
                Console.WriteLine("1. Student");
                Console.WriteLine("2. Lecturer");
                Console.WriteLine("3. Back");
                Console.Write("Register as a Student or Lecturer (1-2) or go back to main screen (3): ");

                if(int.TryParse(Console.ReadLine(), out int option) && Enum.IsDefined(typeof(RegisteredMembers), option))
                {
                    switch((RegisteredMembers)option)
                    {
                        case RegisteredMembers.Student:
                            membersManager.registerStudent();
                            Console.WriteLine("Press any button to return.");
                            break;

                        case RegisteredMembers.Lecturer:
                            membersManager.registerLecturer();
                            Console.WriteLine("Press any button to return.");
                            break;
                    }
                }
                else if(option == 3)
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid option. Press any key to continue.");
                    Console.ReadKey();
                }
            }
        }

        static void viewRegisteredMembers()
        {
            Console.Clear();
            while(true)
            {
                Console.Clear();
                Console.WriteLine("1. View Students");
                Console.WriteLine("2. View Lecturers");
                Console.WriteLine("3. Back");
                Console.Write("View Students or Lecturers (1-2) or go back to main screen (3): ");

                if (int.TryParse(Console.ReadLine(), out int option) && Enum.IsDefined(typeof(ViewMembers), option))
                {
                    switch ((ViewMembers)option)
                    {
                        case ViewMembers.Student:
                            membersManager.viewStudents();
                            Console.WriteLine("Press any button to return.");
                            break;

                        case ViewMembers.Lecturer:
                            membersManager.viewLecturers();
                            Console.WriteLine("Press any button to return.");
                            break;
                    }
                }
                else if (option == 3)
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid option. Press any key to continue.");
                    Console.ReadKey();
                }
            }
        }

        static void placeOrder()
        {
            Console.Clear();
            Console.WriteLine("1. Student Order");
            Console.WriteLine("2. Lecturer Order");
            Console.WriteLine("3. Back");
            Console.Write("Select order type (1-2) or 3 to go back: ");

            if (!int.TryParse(Console.ReadLine(), out int choice)) return;

            string memberType;
            switch (choice)
            {
                case 1:
                    memberType = "Student";
                    break;
                case 2:
                    memberType = "Lecturer";
                    break;
                case 3:
                    return;
                default:
                    Console.WriteLine("Invalid choice.");
                    Console.ReadKey();
                    return;
            }

            Console.Write($"Enter {memberType} ID: ");
            if (!int.TryParse(Console.ReadLine(), out int memberId))
            {
                Console.WriteLine("Invalid ID. Must be a number.");
                Console.ReadKey();
                return;
            }

            bool exists;

            if(memberType == "Student")
            {
                exists = membersManager.studentExists(memberId);
            }
            else
            {
                exists = membersManager.lecturerExists(memberId);
            }

            if(!exists)
            {
                Console.WriteLine($"{memberType} with ID {memberId} not found!");
                Console.ReadKey();
                return;
            }

            ordersManager.placeOrder(memberType, memberId);
            Console.WriteLine("Press any key to continue.");
            Console.ReadKey();
        }

        static void viewOrders()
        {
            Console.Clear();
            Console.WriteLine("1. View All Orders");
            Console.WriteLine("2. View Student Orders");
            Console.WriteLine("3. View Lecturer Orders");
            Console.WriteLine("4. View Orders by ID");
            Console.WriteLine("5. Back");
            Console.Write("Select an option: ");

            if (!int.TryParse(Console.ReadLine(), out int choice)) return;

            switch (choice)
            {
                case 1:
                    ordersManager.viewOrders();
                    break;
                case 2:
                    ordersManager.viewOrders("Student");
                    break;
                case 3:
                    ordersManager.viewOrders("Lecturer");
                    break;
                case 4:
                    Console.Write("Enter Member ID: ");
                    if (int.TryParse(Console.ReadLine(), out int id))
                        ordersManager.viewOrderById(id);
                    else
                        Console.WriteLine("Invalid ID.");
                    break;
                case 5:
                    return;
                default:
                    Console.WriteLine("Invalid choice.");
                    break;
            }

            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
        }

        static void Main(string[] args)
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("1. Register");
                Console.WriteLine("2. View Registered Members");
                Console.WriteLine("3. Place An Order");
                Console.WriteLine("4. View Placed Orders");
                Console.WriteLine("5. Exit");
                Console.Write("Select an option (1-5): ");

                if (int.TryParse(Console.ReadLine(), out int option) && Enum.IsDefined(typeof(Menu), option))
                {
                    switch ((Menu)option)
                    {
                        case Menu.Register:
                            register();
                            break;

                        case Menu.ViewRegisteredMembers:
                            viewRegisteredMembers();
                            break;

                        case Menu.PlaceAnOrder:
                            placeOrder();
                            break;

                        case Menu.ViewPlacedOrders:
                            viewOrders();
                            break;

                        case Menu.Exit:
                            Environment.Exit(0);
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Invalid option. Press any key to continue.");
                    Console.ReadKey();
                }
            }

            Console.ReadKey();
        }
    }
}
