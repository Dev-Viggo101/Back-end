﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App
{
    internal class Student : Members
    {
        public int Id { get; set; }

        public override void displayInfo()
        {
            Console.WriteLine($"[Student] {fullname} | ID: {Id}");
        }
    }
}
