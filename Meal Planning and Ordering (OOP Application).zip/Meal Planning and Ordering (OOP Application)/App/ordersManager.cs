﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App
{
    internal class ordersManager
    {
        private List<Order> orders = new List<Order>();

        private readonly string[] meals = { "Pizza", "Burger", "Salad", "Pasta", "Sushi" };

        public void placeOrder(string memberType, int memberId)
        {
            Console.Clear();

            Console.WriteLine("\nSelect a meal:");
            for (int i = 0; i < meals.Length; i++)
            {
                Console.WriteLine($"{i + 1}. {meals[i]}");
            }

            Console.Write("Choice: ");
            if(!int.TryParse(Console.ReadLine(), out int choice) || choice < 1 || choice > meals.Length)
            {
                Console.WriteLine("Invalid meal choice.");
                return;
            }

            Order order;

            if(memberType == "Student")
            {
                order = new StudentOrder();
            }
            else
            {
                order = new LecturerOrder();
            }
            order.Id = memberId;
            order.meal = meals[choice - 1];
            orders.Add(order);

            Console.WriteLine($"Order placed successfully {memberType} ID {memberId}: {order.meal}!");
        }

        public void viewOrders(string memberType = "All")
        {
            Console.Clear();

            List<Order> filteredOrders;
            
            if(memberType == "All")
            {
                filteredOrders = orders;
            }
            else
            {
                filteredOrders= orders.FindAll(o => o.getOrderType() == memberType);
            }

            if(filteredOrders.Count == 0)
            {
                Console.WriteLine("No orders found.");
                return;
            }

            foreach (var order in filteredOrders)
            {           
                    order.display();
            }
        }

        public void viewOrderById(int memberId)
        {
            Console.Clear();

            var filteredOrders = orders.FindAll(o => o.Id == memberId);

            if(filteredOrders.Count == 0)
            {
                Console.WriteLine($"No orders found for ID {memberId}.");
                return;
            }

            foreach (var order in filteredOrders)
            {
                order.display();
            }
        }
    }
}
