﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App
{
    public abstract class Order
    {
        public int Id { get; set; }
        public string meal { get; set; }

        public abstract string getOrderType();

        public virtual void display()
        {
            Console.WriteLine($"[{getOrderType()}] ID: {Id} - Meal: {meal}");
        }
    }
}
