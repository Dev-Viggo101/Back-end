﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App
{
    public abstract class Members
    {
        public string fullname { get; set; }

        public abstract void displayInfo();
    }
}
