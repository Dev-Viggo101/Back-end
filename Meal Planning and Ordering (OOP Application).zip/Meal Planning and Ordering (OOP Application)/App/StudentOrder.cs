﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App
{
    internal class StudentOrder : Order
    {
        public override string getOrderType() => "Student";
    }
}
