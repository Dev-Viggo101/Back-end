﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace App
{
    enum Menu
    {
        Add = 1,
        Display,
        Search,
        Exit
    }

    class Student
    {
        public string Fullname {  get; set; }
        public string Grade {  get; set; }

        public Student(string fullname, string grade)
        {
            Fullname = fullname;
            Grade = grade;
        }

        public override string ToString()
        {
            return $"{Fullname},{Grade}";
        }

    }
    internal class Program
    {
        static string path = @"C:\Users\27762\OneDrive\Desktop\GitHub Projects\Student Grades Manager\Students.txt";
        static List<Student> list = new List<Student>();

        static void ShowMenu()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("=== Student Grade Manager ===");
                Console.WriteLine("\n1. Add New Student");
                Console.WriteLine("2. Display All Students");
                Console.WriteLine("3. Search Student");
                Console.WriteLine("4. Exit");
                Console.Write("Select an option (1-4): ");
                if (int.TryParse(Console.ReadLine(), out int option) && Enum.IsDefined(typeof(Menu), option))
                {
                    switch((Menu)option)
                    {
                        case Menu.Add:
                            add();
                            break;
                        case Menu.Display:
                            display();
                            break;
                        case Menu.Search: 
                            search();
                            break;
                        case Menu.Exit:
                            Environment.Exit(0);
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Invalid option! Please try again.");
                }
            }
        }

        static void add()
        {
            Console.Clear();

            Console.Write("Enter student's fullname: ");
            string fullname = Console.ReadLine();

            Console.Write("Enter student's grade: ");
            string grade = Console.ReadLine();

            using(StreamWriter stream = new StreamWriter(path, append: true))
            {
                stream.WriteLine($"{fullname},{grade}");
            }
            Console.WriteLine("Student added successfully.");
            Console.WriteLine("\nPress any key to continue.");
            Console.ReadKey();
        }

        static void display()
        {
            Console.Clear();
            if (!File.Exists(path))
            {
                Console.WriteLine("No students found yet.");
                return;
            }
            else
            {
                using (StreamReader reader = new StreamReader(path))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        Console.WriteLine(line);
                    }
                }
            }
            Console.WriteLine("\nPress any key to continue.");
            Console.ReadKey();
        }

        static void search() 
        { 
            Console.Clear(); 
            if (!File.Exists(path)) 
            { 
                Console.WriteLine("No students found yet."); 
                return; 
            } 
            
            Console.Write("Enter student's fullname to search: "); 
            string searchFullname = Console.ReadLine(); 
            
            string[] lines = File.ReadAllLines(path); 
            foreach (string line in lines) 
            { 
                string[] parts = line.Split(','); 
                if (parts[0].Equals(searchFullname, StringComparison.OrdinalIgnoreCase)) 
                { 
                    Console.WriteLine($"{parts[0]}: {parts[1]}");
                    Console.WriteLine("Press any key to continue.");
                    Console.ReadKey();
                    return; 
                } 
            } 
            Console.WriteLine("Student not found.");
            Console.WriteLine("Press any key to continue.");
            Console.ReadKey();
        }


        static void Main(string[] args)
        {
            ShowMenu();
            Console.ReadKey();
        }
    }
}
